import React from 'react';
import './App.css';
import Exercicio1 from './components/Exercicio1';

function App() {
  return (
    <div className="App">
      <Exercicio1 />
    </div>
  );
}

export default App;