import React, { useState } from 'react';
import './Exercicio1.css';

const Exercicio1: React.FC = () => {
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [time, setTime] = useState<number>(0);
  const [inputValue, setInputValue] = useState('');

  const validatePassword = (password: string) => {
    const regex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    setMessage(regex.test(password)
      ? '✅ Senha válida!'
      : '❌ Mín. 8 caracteres, 1 letra, 1 número, 1 caractere especial.');
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setPassword(val);
    validatePassword(val);
  };

  const startCountdown = () => {
    let countdown = parseInt(inputValue);
    if (isNaN(countdown) || countdown <= 0) {
      alert('Digite um número válido.');
      return;
    }

    const interval = setInterval(() => {
      if (countdown === 0) {
        clearInterval(interval);
        setTime(0);
      } else {
        setTime(countdown);
        countdown--;
      }
    }, 1000);
  };

  return (
    <div className="container">
      <h2>🔐 Validador de Senha</h2>
      <input type="password" value={password} onChange={handlePasswordChange} placeholder="Digite sua senha" />
      <p>{message}</p>
      <h2>⏳ Contador Regressivo</h2>
      <input type="number" value={inputValue} onChange={(e) => setInputValue(e.target.value)} placeholder="Digite o número inicial" />
      <button onClick={startCountdown}>Iniciar Contagem</button>
      <h3>{time > 0 ? `Contando: ${time}` : ''}</h3>
    </div>
  );
};

export default Exercicio1;